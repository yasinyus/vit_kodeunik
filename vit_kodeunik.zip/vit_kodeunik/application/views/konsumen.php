<?php defined('BASEPATH') OR exit('No direct script access allowed'); error_reporting(E_ALL | E_STRICT) ?>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
            <div class="content-wrapper">
<style type="text/css">
  .ui-button-text{
    display: none;
  }

  span .glyphicon-plus{
    display: none;
  }

  #form-button-save {
     display: none;
  }
   #cancel-button {
     display: none;
  }
  tfoot { display: none; }

  
</style>

<h3 style="padding-top: 10px; padding-left: 10px;">Data Konsumen</h3>
<?php 

foreach($css_files as $file): ?>
  <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
</head>
<body>
  
  <div style='height:20px;'></div>  
    <div style="padding: 10px">
    <?php echo $output; ?>
    </div>
    <?php foreach($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</div>
<script type="text/javascript">
  $(document).ready(function() {
      $("#save-and-go-back-button").val("Simpan ke database");
   });
  $(document).ready(function() {
      $("#field-status").removeClass("chosen-select");
   });
  $(document).ready(function() {
      $("#field-status").addClass("form-control");
   });
</script>