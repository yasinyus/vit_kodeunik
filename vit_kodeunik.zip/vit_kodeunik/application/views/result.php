
		<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.css">
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.js"></script>
		<style type="text/css">
			.sweet-alert.sweetalert-lg { width: 600px; }
		</style>
 


	<div class="content-wrapper">

	<hr>
 
		<?php
		if(count($cari)>0)
		{
			foreach ($cari as $data) {
            ?>
				<script type="text/javascript">
				Swal.fire({
				  title: '<?= $data->kode_unik?> = <?= $data->nama_hadiah?>',
				 html :
				 <?php
				  	if($cari_konsumen)
					{
					foreach ($cari_konsumen as $data2) {
	            	?>
				   '<a href="<?php echo base_url('/user/konsumen/edit/')?><?= $data2->id ?>"><h3>Pernah di klaim oleh : <?= $data2->nama_konsumen ?></h3><br>'+
				<?php }} ?>
				  '',
				  focusConfirm: false,
				  confirmButtonText:
				    'Gunakan Kode Unik',
				  confirmButtonAriaLabel: 'Thumbs up, great!',
				  width: '450px'
				}).then(function() {
					    window.location = "user/konsumen/add?kode_unik=<?=$data->kode_unik?>&hadiah=<?=$data->nama_hadiah?>&user=<?=$name?>";
					});
			</script>
		<?php
		}
		}
 
		else
		{ ?>
			<script type="text/javascript">
				Swal.fire({
				  title: 'Kode Unik tidak tersedia',
				  type: 'error',
				  showCloseButton: true,
				  width: '450px'
				}).then(function() {
					    window.location = "cari";
					});
			</script>
		<?php
		}
 
		?>
 
	</div>
