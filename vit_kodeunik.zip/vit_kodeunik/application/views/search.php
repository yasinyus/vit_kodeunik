<style type="text/css">
			.centering{
				float:none;
				margin:0 auto
				}
		</style>
<div class="content-wrapper">
	<div class="row d-flex justify-content-center">
	<div class="col-md-6 centering text-center">
    	<section class="content">
			<img src="https://www.dancommunity.co.id/files/logo/TUw1549597124.PNG" width="300px">
           <form action="<?php echo base_url('hasil')?>" action="GET">
				<div class="form-group ">
					<input type="text" class="form-control" id="cari" name="cari" placeholder="cari">
				</div>
				<input class="btn btn-primary" type="submit" value="Cari Kode Unik">
			</form>
    	</section>
	</div>
	</div>
</div>
