<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Orang_model extends CI_Model {
    public function __construct()
    {
        $this->load->database();
    }
    public function cariKodeUnik()
    {
        $cari = $this->input->GET('cari', TRUE);
        $data = $this->db->query("SELECT * FROM kode_unik LEFT JOIN hadiah ON kode_unik.id_hadiah = hadiah.id_hadiah where kode_unik = '$cari' ");
        return $data->result();
    }

    public function cariKodeUnikKonsumen()
    {
        $cari = $this->input->GET('cari', TRUE);
        $data = $this->db->query("SELECT * FROM konsumen LEFT JOIN kode_unik ON konsumen.kode_unik = kode_unik.kode_unik WHERE konsumen.kode_unik = '$cari' ");
        return $data->result();
    }
 
 
}
