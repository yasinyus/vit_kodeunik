<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);

class Data extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('example.php',(array)$output);
	}

	public function offices()
	{
		$output = $this->grocery_crud->render();

		$this->_example_output($output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}


	public function konsumen()
	{
			$crud = new grocery_CRUD();
			$crud->set_theme('tablestrap');
			$crud->set_table('konsumen');
			if ($this->uri->segment(3) == "export") {
			$crud->unset_columns(array('id','status'));
			}
			else{
			$crud->columns('kode_unik','hadiah','nama_konsumen','nama_kota');
			}
			$crud->field_type('kode_unik', 'hidden', $_GET['kode_unik']);
			$crud->field_type('hadiah', 'hidden', $_GET['hadiah']);
			//$crud->unset_add();
			$crud->unset_delete();
			$crud->unset_clone();
			$output = $crud->render();

			$this->_example_output($output);
	}
	
	
}
